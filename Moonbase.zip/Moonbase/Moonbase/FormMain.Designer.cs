﻿namespace Moonbase
{
    partial class Moonbase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Moonbase));
            this.GBcenconroom = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BTNops = new System.Windows.Forms.Button();
            this.BTNeng = new System.Windows.Forms.Button();
            this.BTNsec = new System.Windows.Forms.Button();
            this.BTNcoms = new System.Windows.Forms.Button();
            this.GBcenconroom.SuspendLayout();
            this.SuspendLayout();
            // 
            // GBcenconroom
            // 
            this.GBcenconroom.BackColor = System.Drawing.Color.Gainsboro;
            this.GBcenconroom.Controls.Add(this.textBox2);
            this.GBcenconroom.Controls.Add(this.label2);
            this.GBcenconroom.Controls.Add(this.textBox1);
            this.GBcenconroom.Controls.Add(this.label1);
            this.GBcenconroom.Location = new System.Drawing.Point(23, 22);
            this.GBcenconroom.Name = "GBcenconroom";
            this.GBcenconroom.Size = new System.Drawing.Size(483, 477);
            this.GBcenconroom.TabIndex = 0;
            this.GBcenconroom.TabStop = false;
            this.GBcenconroom.Text = "Location Information";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(42, 148);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(404, 270);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = resources.GetString("textBox2.Text");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(186, 26);
            this.label2.TabIndex = 2;
            this.label2.Text = "Room Description";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(42, 64);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(270, 35);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "Central Control Room";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(37, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Room Name";
            // 
            // BTNops
            // 
            this.BTNops.Location = new System.Drawing.Point(143, 540);
            this.BTNops.Name = "BTNops";
            this.BTNops.Size = new System.Drawing.Size(77, 39);
            this.BTNops.TabIndex = 1;
            this.BTNops.Text = "Ops";
            this.BTNops.UseVisualStyleBackColor = true;
            this.BTNops.Click += new System.EventHandler(this.BTNops_Click);
            // 
            // BTNeng
            // 
            this.BTNeng.Location = new System.Drawing.Point(258, 540);
            this.BTNeng.Name = "BTNeng";
            this.BTNeng.Size = new System.Drawing.Size(77, 39);
            this.BTNeng.TabIndex = 2;
            this.BTNeng.Text = "Eng";
            this.BTNeng.UseVisualStyleBackColor = true;
            this.BTNeng.Click += new System.EventHandler(this.BTNeng_Click);
            // 
            // BTNsec
            // 
            this.BTNsec.Location = new System.Drawing.Point(1572, 530);
            this.BTNsec.Name = "BTNsec";
            this.BTNsec.Size = new System.Drawing.Size(85, 39);
            this.BTNsec.TabIndex = 3;
            this.BTNsec.Text = "Security";
            this.BTNsec.UseVisualStyleBackColor = true;
            this.BTNsec.Click += new System.EventHandler(this.BTNres_Click);
            // 
            // BTNcoms
            // 
            this.BTNcoms.Location = new System.Drawing.Point(1688, 530);
            this.BTNcoms.Name = "BTNcoms";
            this.BTNcoms.Size = new System.Drawing.Size(77, 39);
            this.BTNcoms.TabIndex = 4;
            this.BTNcoms.Text = "Coms";
            this.BTNcoms.UseVisualStyleBackColor = true;
            this.BTNcoms.Click += new System.EventHandler(this.BTNcoms_Click);
            // 
            // Moonbase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1898, 1024);
            this.Controls.Add(this.BTNcoms);
            this.Controls.Add(this.BTNsec);
            this.Controls.Add(this.BTNeng);
            this.Controls.Add(this.BTNops);
            this.Controls.Add(this.GBcenconroom);
            this.Name = "Moonbase";
            this.Text = "Cosmos Command";
            this.GBcenconroom.ResumeLayout(false);
            this.GBcenconroom.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GBcenconroom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button BTNops;
        private System.Windows.Forms.Button BTNeng;
        private System.Windows.Forms.Button BTNsec;
        private System.Windows.Forms.Button BTNcoms;
    }
}

