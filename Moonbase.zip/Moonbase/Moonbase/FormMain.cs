﻿/*
 Jeremy Gurzynski
 CSC202
 jgurzynski85952@uat.edu
 Week 1 MoonBase Alpha I Assignment
 */

//Lines 1-9 are used for various functionalities of C#
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Name of our file
namespace Moonbase
{
    //Declares our Moonbase that inherits from form
    public partial class Moonbase : Form
    {  
        //Constructor for our form
        public Moonbase()
        {
            //Initializes control objects, properties, and adds to proper control collections.
            InitializeComponent();
        }
        //Function called when button is pressed.
        private void BTNops_Click(object sender, EventArgs e)
        {
            //Message box will appear once button is selected.
            MessageBox.Show("Operations Station: Oversees and coordinates all mission activities and operational directives.");
        }
        //Function called when button is pressed.
        private void BTNeng_Click(object sender, EventArgs e)
        {
            //Message box will appear once button is selected.
            MessageBox.Show("Engineering Station: Monitors all technical systems and base infrastructure.");
        }
        //Function called when button is pressed.
        private void BTNres_Click(object sender, EventArgs e)
        {
            //Message box will appear once button is selected.
            MessageBox.Show("Security Station: Conducts and oversees all security of the command.");
        }
        //Function called when button is pressed.
        private void BTNcoms_Click(object sender, EventArgs e)
        {
            //Message box will appear once button is selected.
            MessageBox.Show("Communications Station: Manages all external communications between Earth and the Moon, as well as internal communications within the base.");
        }
    }
}
